"""SafeResolve customer support agent."""
from .agent import SupportAgent
__all__ = ["SupportAgent"]
