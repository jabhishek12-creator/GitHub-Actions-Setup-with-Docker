import re
from dataclasses import dataclass

@dataclass
class ToolResult:
    ok: bool
    output: str

INVOICES = {"INV-1001": "paid", "INV-1002": "payment failed", "INV-1003": "pending"}
def service_status(component: str = "platform") -> ToolResult:
    statuses = {"platform": "operational", "login": "operational", "api": "degraded; incident INC-42; no ETA available"}
    key = component.lower(); return ToolResult(key in statuses, statuses.get(key, "unknown component"))
def invoice_status(invoice_id: str) -> ToolResult:
    if not re.fullmatch(r"INV-\d{4}", invoice_id.upper()): return ToolResult(False, "invalid invoice ID format; expected INV-1234")
    status = INVOICES.get(invoice_id.upper()); return ToolResult(status is not None, status or "invoice not found; escalate for secure lookup")
READ_ONLY_TOOLS = {"service_status": service_status, "invoice_status": invoice_status}
