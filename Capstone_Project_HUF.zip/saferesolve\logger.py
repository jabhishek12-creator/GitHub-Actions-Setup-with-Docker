import json, time
from pathlib import Path
from .safety import fingerprint, redact

class SafeLogger:
    def __init__(self, path: str | Path = "artifacts/interactions.jsonl"):
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
    def write(self, session_id: str, text: str, response):
        event = {"timestamp": int(time.time()), "session_id": fingerprint(session_id), "input": redact(text), "input_fingerprint": fingerprint(text), "outcome": response.outcome, "confidence": response.confidence, "citations": response.citations, "tools": response.tools_used, "latency_ms": response.latency_ms, "error": response.metadata.get("error")}
        with self.path.open("a", encoding="utf-8") as f: f.write(json.dumps(event) + "\n")
