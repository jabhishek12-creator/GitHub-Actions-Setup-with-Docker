"""Double-click launcher for SafeResolve on Windows (no terminal required)."""
import os
import socket
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

URL = "http://127.0.0.1:8000/"
ERROR_LOG = ROOT / "artifacts" / "launcher_error.log"


def already_running() -> bool:
    try:
        with urllib.request.urlopen(URL + "health", timeout=1) as response:
            return response.status == 200
    except Exception:
        return False


def open_when_ready() -> None:
    for _ in range(30):
        if already_running():
            webbrowser.open(URL)
            return
        time.sleep(0.2)


try:
    if already_running():
        webbrowser.open(URL)
    else:
        from http.server import ThreadingHTTPServer
        from saferesolve.server import Handler

        threading.Thread(target=open_when_ready, daemon=True).start()
        ThreadingHTTPServer(("127.0.0.1", 8000), Handler).serve_forever()
except Exception:
    ERROR_LOG.parent.mkdir(exist_ok=True)
    ERROR_LOG.write_text(traceback.format_exc(), encoding="utf-8")
    webbrowser.open(ERROR_LOG.as_uri())
