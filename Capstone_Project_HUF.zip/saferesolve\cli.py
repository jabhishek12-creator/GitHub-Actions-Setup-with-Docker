import argparse, json
from .agent import SupportAgent

def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--offline", action="store_true"); args = parser.parse_args()
    agent = SupportAgent(offline=args.offline); print("SafeResolve ready. Commands: /reset, /feedback 1-5, /quit")
    while True:
        text = input("You: ").strip()
        if text == "/quit": break
        if text == "/reset": agent.reset(); print("Memory cleared."); continue
        if text.startswith("/feedback "): agent.add_feedback(int(text.split()[1])); print("Feedback saved."); continue
        print(json.dumps(agent.respond(text).as_dict(), indent=2))
if __name__ == "__main__": main()
