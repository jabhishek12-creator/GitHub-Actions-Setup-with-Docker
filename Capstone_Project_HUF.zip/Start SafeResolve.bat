@echo off
cd /d "%~dp0"
start "" /b pythonw "%~dp0launch_saferesolve.pyw"
exit /b 0
