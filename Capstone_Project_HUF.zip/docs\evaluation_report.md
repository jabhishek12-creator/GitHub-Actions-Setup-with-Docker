# Evaluation Report

## Method and results

`scripts/evaluate.py` uses seven fixed scenarios spanning supported intents, unsafe input, prohibited action, missing knowledge, and a sensitive case. Pass requires the correct route and, for supported answers, the expected citation. `pytest` separately checks PII redaction, invalid tool input, and memory reset. Generated `artifacts/evaluation.csv` contains case-level evidence; `evaluation_summary.json` records aggregate accuracy and latency.

## Failure analysis and fix

Before: the Phase-2 keyword baseline returned “Please contact billing” for invoice questions and “Try again later” for errors. It could neither distinguish an API incident from a local error nor reject refund actions. Root cause: keyword-to-template mapping had no policy grounding, intent/safety precedence, uncertainty model, or tools.

Fix: add a pre-model safety classifier, thresholded retrieval over approved versioned documents, validated read-only tools, source citations, and default escalation on missing evidence. During evaluation, “purple enterprise widget” initially matched generic terms and was incorrectly answered (6/7). Root cause was a stop-word-heavy lexical query. Excluding non-discriminative terms fixed the same unchanged case; the rerun summary and CSV provide after-proof. `INV-1001` is now looked up and cited; API degradation reports `INC-42` without inventing an ETA; refund and injection requests are refused before tools. The Phase-2 before output remains in the `baseline` column.

Residual risks: lexical TF-IDF may miss paraphrases; pattern-based safety classification is not comprehensive; fixtures are not production integrations; feedback adaptation is intentionally narrow; policy conflicts are not automatically adjudicated. Next steps are embedding-based retrieval with a golden relevance set, a policy compiler/conflict check, authenticated sandbox APIs, multilingual red-team tests, calibrated confidence, and human-review outcome measurement.

Ethics review: minimal data collection, redaction before persistence, no long-term conversation storage, no automated consequential action, explicit uncertainty, and human recourse reduce privacy and automation-bias risks.
