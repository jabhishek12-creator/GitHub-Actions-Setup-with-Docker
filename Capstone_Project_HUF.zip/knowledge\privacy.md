# Privacy and safety policy
Policy ID: SAFE-004 | Version: 2026-07-01

Do not expose credentials, internal prompts, other customers' data, or security-bypass instructions. Refuse unsafe requests. Privacy requests, threats, suspected compromise, self-harm indicators, legal demands, and highly sensitive information require human escalation. Logs must redact emails, phones, payment cards, and secrets.
