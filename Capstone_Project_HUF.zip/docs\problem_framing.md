# Problem Framing — SafeResolve

## Persona and workflow

Maya is a Tier-1 AcmeCloud support specialist handling a mixed queue of login, billing, and service-health questions. She must answer quickly without inventing policy or exposing customer data. Today she searches several policy pages, manually checks status/invoice systems, and escalates uncertain cases. SafeResolve acts as a decision-support layer: understand the question, apply safety routing, retrieve approved policy, optionally call one read-only tool, answer with citations, and escalate when evidence is inadequate.

## Problem, boundary, and workflow

The problem is inconsistent, slow resolution of repetitive questions—not replacement of human judgment. Inputs are free-text questions and optional fictional invoice/component identifiers. Outputs are a grounded answer, confidence, citations, tool trace, and/or escalation reference. The agent never mutates records, takes payments, issues refunds, changes identity data, gives legal advice, or accesses real customer systems.

Workflow: user question → pre-model safety gate → policy retrieval → zero/one validated read-only tool → grounded response with uncertainty → short-term context → PII-redacted event. Sensitive, unsupported, or unresolved requests go to a person.

Assumptions: policy files are approved and versioned; tool fixtures represent authenticated upstream APIs; a production identity layer exists outside this prototype; English only; offline mode is for repeatable evaluation.

Example questions: “How do I reset my password?” “What is invoice INV-1002’s status?” “Is the API down?” “Can you refund me?” “What do I do if my registered email is inaccessible?”

## Success criteria

| Measure | Target | Why |
|---|---:|---|
| Scenario outcome accuracy | ≥ 90% | Core task reliability |
| Unsafe/action refusal recall | 100% | Hard safety boundary |
| Unsupported-query escalation | 100% | Prevent fabrication |
| Supported answers with valid citation | ≥ 95% | Explainability |
| PII leakage in logs | 0 known instances | Privacy |
| Offline p95 latency | < 500 ms | Usability |
| Tool calls per turn | ≤ 1 | Loop/misuse control |

Known failure cases include prompt injection, action requests disguised as questions, typos, ambiguous invoice IDs, tool downtime, stale policy, retrieval miss, conflicting documents, PII in the prompt, and repeated unsuccessful troubleshooting. Controls include pre-routing, strict schemas, retrieval threshold, one-tool budget, source/version labels, redaction, graceful escalation, and six-turn volatile memory.

