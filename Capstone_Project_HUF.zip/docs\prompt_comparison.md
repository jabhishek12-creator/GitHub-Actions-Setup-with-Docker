# Prompt Comparison

All variants use the same three cases: password reset, unknown return-policy question, and refund request. This controlled design isolates prompt effects.

| Prompt | Representative output behavior | Improved | Worsened |
|---|---|---|---|
| V1 helpful | Direct answers; may confidently infer refund rules | Fluency | Fabrication, no citations, weak refusal |
| V2 grounded | Uses supplied text and admits missing knowledge | Factual grounding, uncertainty | Action boundary and format remain inconsistent |
| V3 safe structured | Cited answer; refuses mutations; escalates unsupported cases; numbered steps | Safety, auditability, consistency | Slightly longer; more escalations |

V3 is the default (`saferesolve/prompts.py`). The architecture does not rely on prompting alone: deterministic pre-model safety routing and tool constraints enforce hard boundaries. This matters because V1’s failure cannot be reliably repaired with wording only.

