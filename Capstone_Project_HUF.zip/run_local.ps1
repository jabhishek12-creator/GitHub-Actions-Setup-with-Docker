$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
Write-Host "Starting SafeResolve..." -ForegroundColor Cyan
Write-Host "Keep this window open, then visit http://127.0.0.1:8000" -ForegroundColor Green
python -m saferesolve.server
