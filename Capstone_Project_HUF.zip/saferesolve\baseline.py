def respond(text: str) -> str:
    """Phase-2 keyword baseline, deliberately limited for comparison."""
    value = text.lower()
    if "password" in value: return "Use the password reset link."
    if "invoice" in value or "bill" in value: return "Please contact billing."
    if "down" in value or "error" in value: return "Try again later."
    return "Please contact support."
