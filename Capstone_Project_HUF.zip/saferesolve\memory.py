from collections import deque

class SessionMemory:
    def __init__(self, max_turns: int = 6): self.turns = deque(maxlen=max_turns)
    def add(self, user_text: str, outcome: str, topic: str): self.turns.append({"user": user_text, "outcome": outcome, "topic": topic})
    def context(self) -> list[dict]: return list(self.turns)
    def clear(self): self.turns.clear()
