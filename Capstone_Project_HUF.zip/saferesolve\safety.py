import hashlib, os, re
from dataclasses import dataclass

EMAIL = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
PHONE = re.compile(r"(?<!\w)(?:\+?\d[\d\s().-]{7,}\d)(?!\w)")
CARD = re.compile(r"\b(?:\d[ -]*?){13,19}\b")
SECRET = re.compile(r"(?i)\b(?:api[_ -]?key|password|secret|token)\s*[:=]\s*\S+")
UNSAFE = ("reveal your system prompt", "bypass security", "steal", "hack", "other customer's")
ACTION = ("issue a refund", "refund me", "cancel my subscription", "change my password", "delete my account", "change payment")
SENSITIVE = ("chargeback", "legal", "lawyer", "suicide", "self-harm", "data breach", "compromised")

def redact(text: str) -> str:
    return SECRET.sub("[REDACTED_SECRET]", PHONE.sub("[REDACTED_PHONE]", CARD.sub("[REDACTED_CARD]", EMAIL.sub("[REDACTED_EMAIL]", text))))

def fingerprint(text: str) -> str:
    salt = os.getenv("SAFERESOLVE_LOG_SALT", "local-development-salt")
    return hashlib.sha256((salt + text).encode()).hexdigest()[:16]

@dataclass
class SafetyDecision:
    route: str
    reason: str = ""

def classify(text: str) -> SafetyDecision:
    value = text.lower()
    if any(x in value for x in UNSAFE): return SafetyDecision("refuse", "unsafe_or_policy_violating")
    if any(x in value for x in SENSITIVE): return SafetyDecision("escalate", "sensitive_or_high_risk")
    if any(x in value for x in ACTION): return SafetyDecision("refuse_action", "agent_is_read_only")
    return SafetyDecision("allow")
