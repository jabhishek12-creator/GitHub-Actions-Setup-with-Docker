# Service incident policy
Policy ID: SVC-003 | Version: 2026-07-01

The status tool is authoritative. If a component is degraded, share its incident reference and do not promise a restoration time unless provided. If operational, suggest verifying network access, retrying once, and recording the error code. Escalate after two failed steps.
