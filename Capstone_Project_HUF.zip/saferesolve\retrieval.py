import math, re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

TOKEN = re.compile(r"[a-z0-9]+")
STOP = {"a", "an", "and", "are", "as", "at", "be", "by", "can", "do", "for", "from", "get", "how", "i", "if", "in", "is", "it", "me", "my", "of", "on", "or", "please", "the", "this", "to", "what", "with", "you", "your", "about", "enterprise"}
def terms(text: str): return [t for t in TOKEN.findall(text.lower()) if t not in STOP]
@dataclass
class Document:
    source: str
    text: str
    score: float = 0.0

class LocalRetriever:
    """Deterministic TF-IDF retriever used for reproducible offline evaluation."""
    def __init__(self, path: str | Path = "knowledge"):
        self.docs = [Document(p.name, p.read_text(encoding="utf-8")) for p in Path(path).glob("*.md")]
        self.tokens = [Counter(terms(d.text)) for d in self.docs]
        n = max(len(self.docs), 1); vocabulary = {t for c in self.tokens for t in c}
        self.idf = {t: math.log((n + 1) / (1 + sum(t in c for c in self.tokens))) + 1 for t in vocabulary}
    def search(self, query: str, k: int = 2, threshold: float = 0.08) -> list[Document]:
        q = Counter(terms(query)); scored = []
        for doc, counts in zip(self.docs, self.tokens):
            num = sum(q[t] * counts[t] * self.idf.get(t, 0) ** 2 for t in q)
            qn = math.sqrt(sum((v * self.idf.get(t, 0)) ** 2 for t, v in q.items()))
            dn = math.sqrt(sum((v * self.idf.get(t, 0)) ** 2 for t, v in counts.items()))
            score = num / (qn * dn) if qn and dn else 0
            if score >= threshold: scored.append(Document(doc.source, doc.text, round(score, 3)))
        return sorted(scored, key=lambda d: d.score, reverse=True)[:k]
