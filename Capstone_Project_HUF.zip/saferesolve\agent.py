import os, re, time, uuid
from .feedback import FeedbackStore
from .logger import SafeLogger
from .memory import SessionMemory
from .models import AgentResponse
from .prompts import DEFAULT_PROMPT
from .retrieval import LocalRetriever
from .safety import classify
from .tools import invoice_status, service_status

class SupportAgent:
    def __init__(self, offline: bool = True, session_id: str | None = None, knowledge_path: str = "knowledge", log_path: str = "artifacts/interactions.jsonl"):
        self.offline = offline; self.session_id = session_id or uuid.uuid4().hex[:8]
        self.retriever = LocalRetriever(knowledge_path); self.memory = SessionMemory(); self.feedback = FeedbackStore(); self.logger = SafeLogger(log_path)

    def reset(self): self.memory.clear()
    def add_feedback(self, rating: int, reason: str = ""): self.feedback.add(self.session_id, rating, reason)
    def _escalate(self, reason: str) -> AgentResponse:
        ref = "ESC-" + uuid.uuid4().hex[:8].upper()
        return AgentResponse(f"I can’t safely resolve this here. I’ve prepared escalation reference {ref} for a human support specialist. Please avoid sharing passwords, codes, or full payment details. Reason: {reason}.", "escalated", 1.0, escalation_id=ref)
    def _offline_answer(self, text: str, docs, tool_note: str, explicit: bool) -> str:
        lead = "Based on the approved support policy, "
        low = text.lower()
        if "password" in low or "sign in" in low or "login" in low:
            body = "use **Forgot password** on the sign-in page; the link expires after 30 minutes. If you cannot access the registered email, a human Identity specialist must help."
        elif "invoice" in low:
            body = tool_note or "I need a valid invoice ID such as INV-1001 to perform a read-only status lookup."
        elif "api" in low or "service" in low or "down" in low:
            body = tool_note or "check the current service status, retry once, and record any displayed error code."
        else: body = "the available documents do not contain enough information to answer confidently."
        steps = "\n\nNext steps:\n1. Follow the guidance above.\n2. If it fails twice, ask for human support." if explicit else ""
        cites = " ".join(f"[{d.source}]" for d in docs)
        return f"{lead}{body}{steps}\n\nSources: {cites}".strip()

    def _live_answer(self, text: str, docs, tool_note: str) -> str:
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage, SystemMessage
        context = "\n\n".join(f"SOURCE {d.source}:\n{d.text}" for d in docs)
        model = ChatOpenAI(model="gpt-4.1-mini", temperature=0)
        return model.invoke([SystemMessage(content=DEFAULT_PROMPT), HumanMessage(content=f"APPROVED CONTEXT:\n{context}\nTOOL RESULTS:\n{tool_note}\nUSER:\n{text}")]).content

    def respond(self, text: str) -> AgentResponse:
        start = time.perf_counter(); decision = classify(text); plan = ["safety gate"]
        if decision.route == "refuse": response = AgentResponse("I can’t help bypass safeguards, expose protected instructions, or access another customer’s information. I can help with legitimate account support.", "refused", 1.0, plan=plan)
        elif decision.route == "refuse_action": response = AgentResponse("I can explain the applicable policy, but I cannot modify accounts, cancel services, change payment details, or issue refunds. I can escalate the request to a human specialist.", "refused_action", 1.0, plan=plan)
        elif decision.route == "escalate": response = self._escalate(decision.reason); response.plan = plan
        else:
            plan += ["retrieve approved policy", "select at most one read-only tool", "compose grounded response"]
            docs = self.retriever.search(text); tools = []; tool_note = ""
            inv = re.search(r"\bINV-\d+\b", text, re.I)
            if inv:
                result = invoice_status(inv.group()); tools = ["invoice_status"]; tool_note = f"Invoice {inv.group().upper()} status: {result.output}."
                if not result.ok: response = self._escalate("invoice lookup could not be completed"); docs = []
                else: response = None
            elif any(x in text.lower() for x in ("api", "service status", "platform down")):
                component = "api" if "api" in text.lower() else "platform"; result = service_status(component); tools = ["service_status"]; tool_note = f"{component} status: {result.output}."; response = None
            else: response = None
            if response is None and not docs:
                response = self._escalate("no approved knowledge matched the question")
            elif response is None:
                try:
                    answer = self._offline_answer(text, docs, tool_note, self.feedback.preference(self.session_id) == "more_explicit") if self.offline or not os.getenv("OPENAI_API_KEY") else self._live_answer(text, docs, tool_note)
                    response = AgentResponse(answer, "answered", min(.95, .55 + docs[0].score), [d.source for d in docs], tools_used=tools, plan=plan)
                except Exception as exc:
                    response = self._escalate("the language service is temporarily unavailable"); response.metadata["error"] = type(exc).__name__
        response.latency_ms = round((time.perf_counter() - start) * 1000); self.memory.add(text, response.outcome, response.citations[0] if response.citations else "safety"); self.logger.write(self.session_id, text, response); return response
