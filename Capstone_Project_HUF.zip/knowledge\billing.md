# Billing and refunds policy
Policy ID: BILL-002 | Version: 2026-07-01

The agent may explain invoices and retrieve a fictional invoice status by invoice ID. It cannot issue refunds, cancel subscriptions, change payment methods, or promise an adjustment. Duplicate-charge reports, chargebacks, disputed amounts, or requests involving financial action must be escalated to Billing. Never request a full card number; the last four digits are sufficient for a human-led investigation.
