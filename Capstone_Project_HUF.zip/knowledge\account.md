# Account access policy
Policy ID: ACCT-001 | Version: 2026-07-01

For password problems, users should use **Forgot password** on the sign-in page. Reset links expire after 30 minutes. Support must never request or reveal a password, recovery code, API key, or full payment-card number. If a user no longer controls the registered email address, escalate to the Identity team; the agent must not change account ownership or authentication details.

