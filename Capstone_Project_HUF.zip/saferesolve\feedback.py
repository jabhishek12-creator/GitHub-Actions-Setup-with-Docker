import json
from pathlib import Path
from .safety import redact

class FeedbackStore:
    def __init__(self, path: str | Path = "artifacts/feedback.jsonl"):
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
    def add(self, session_id: str, rating: int, reason: str = ""):
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"session_id": session_id, "rating": max(1, min(5, rating)), "reason": redact(reason)[:200]}) + "\n")
    def preference(self, session_id: str) -> str:
        if not self.path.exists(): return "standard"
        rows = [json.loads(x) for x in self.path.read_text(encoding="utf-8").splitlines() if x]
        recent = [r for r in rows if r["session_id"] == session_id][-3:]
        return "more_explicit" if recent and sum(r["rating"] for r in recent) / len(recent) <= 2 else "standard"
