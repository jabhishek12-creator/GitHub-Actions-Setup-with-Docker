import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from .agent import SupportAgent

AGENTS: dict[str, SupportAgent] = {}
INDEX = b"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width'><title>SafeResolve</title><style>body{font:16px system-ui;max-width:760px;margin:40px auto;padding:0 18px;background:#f5f7fb;color:#172033}main{background:white;padding:28px;border-radius:14px;box-shadow:0 4px 24px #0001}textarea{width:100%;box-sizing:border-box;padding:12px}button{margin-top:10px;padding:10px 18px;background:#155eef;color:white;border:0;border-radius:7px}pre{white-space:pre-wrap;background:#eef3ff;padding:14px;border-radius:8px;min-height:70px}.ok{color:#18794e}</style></head><body><main><h1>SafeResolve</h1><p class='ok'>Agent online (offline deterministic mode)</p><textarea id='q' rows='4' placeholder='Ask an AcmeCloud support question...'>Is the API down?</textarea><br><button onclick='send()'>Send</button><pre id='out'>Ready.</pre></main><script>async function send(){let o=document.getElementById('out');o.textContent='Working...';try{let r=await fetch('/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({session_id:'browser',message:document.getElementById('q').value})});let d=await r.json();o.textContent=d.answer||JSON.stringify(d,null,2)}catch(e){o.textContent='Connection error: '+e}}</script></body></html>"""

def get_agent(session_id: str) -> SupportAgent:
    if session_id not in AGENTS:
        AGENTS[session_id] = SupportAgent(offline=True, session_id=session_id)
    return AGENTS[session_id]

class Handler(BaseHTTPRequestHandler):
    def send_json(self, status: int, data: dict):
        body = json.dumps(data).encode()
        self.send_response(status); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if self.path == "/":
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(INDEX))); self.end_headers(); return self.wfile.write(INDEX)
        if self.path == "/health": return self.send_json(200, {"status": "healthy"})
        if self.path == "/agents": return self.send_json(200, {"agents": [{"id": "saferesolve", "mode": "offline", "sessions": len(AGENTS)}]})
        if self.path == "/favicon.ico": self.send_response(204); self.end_headers(); return
        return self.send_json(404, {"error": "not_found"})
    def do_POST(self):
        try:
            size = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(size) or b"{}")
            session = str(payload.get("session_id", "docker"))[:64]
            if self.path == "/chat":
                message = str(payload.get("message", ""))[:4000]
                if not message: return self.send_json(400, {"error": "message_required"})
                return self.send_json(200, get_agent(session).respond(message).as_dict())
            if self.path == "/reset": get_agent(session).reset(); return self.send_json(200, {"status": "reset"})
            return self.send_json(404, {"error": "not_found"})
        except (ValueError, json.JSONDecodeError): return self.send_json(400, {"error": "invalid_json"})
    def log_message(self, format, *args): pass

def main():
    print("SafeResolve is running. Open http://127.0.0.1:8000", flush=True)
    ThreadingHTTPServer(("0.0.0.0", 8000), Handler).serve_forever()

if __name__ == "__main__": main()
