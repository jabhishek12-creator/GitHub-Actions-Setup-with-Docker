from dataclasses import dataclass, field
from typing import Any

@dataclass
class AgentResponse:
    answer: str
    outcome: str
    confidence: float
    citations: list[str] = field(default_factory=list)
    tools_used: list[str] = field(default_factory=list)
    escalation_id: str | None = None
    plan: list[str] = field(default_factory=list)
    latency_ms: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    def as_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()
